const products = [
  { id: 1, name: "Notebook Gamer", price: 3999, img: "https://via.placeholder.com/300" },
  { id: 2, name: "Smartphone", price: 1899, img: "https://via.placeholder.com/300" },
  { id: 3, name: "Fone Bluetooth", price: 199, img: "https://via.placeholder.com/300" },
  { id: 4, name: "Smart TV", price: 2499, img: "https://via.placeholder.com/300" }
];

const id = localStorage.getItem("product");
const product = products.find(p => p.id == id);

document.getElementById("product-detail").innerHTML = `
  <div class="product">
    <img src="${product.img}">
    <h2>${product.name}</h2>
    <p class="price">R$ ${product.price}</p>
    <button onclick="addToCart(${product.id})">Comprar</button>
  </div>
`;

function addToCart(id) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.push(product);
  localStorage.setItem("cart", JSON.stringify(cart));
  alert("Adicionado ao carrinho!");
}

function goHome() {
  window.location.href = "index.html";
}