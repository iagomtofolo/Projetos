const products = [
  { id: 1, name: "Notebook Gamer", price: 3999, img: "https://via.placeholder.com/300" },
  { id: 2, name: "Smartphone", price: 1899, img: "https://via.placeholder.com/300" },
  { id: 3, name: "Fone Bluetooth", price: 199, img: "https://via.placeholder.com/300" },
  { id: 4, name: "Smart TV", price: 2499, img: "https://via.placeholder.com/300" }
];

let cart = JSON.parse(localStorage.getItem("cart")) || [];

function renderProducts(list = products) {
  const container = document.getElementById("product-list");
  container.innerHTML = "";

  list.forEach(p => {
    container.innerHTML += `
      <div class="product">
        <img src="${p.img}" onclick="viewProduct(${p.id})">
        <h3>${p.name}</h3>
        <p class="price">R$ ${p.price}</p>
        <button onclick="addToCart(${p.id})">Comprar</button>
      </div>
    `;
  });
}

function filterProducts() {
  const search = document.getElementById("search").value.toLowerCase();
  const maxPrice = document.getElementById("price-filter").value;
  document.getElementById("price-value").innerText = maxPrice;

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(search) && p.price <= maxPrice
  );

  renderProducts(filtered);
}

function viewProduct(id) {
  localStorage.setItem("product", id);
  window.location.href = "product.html";
}

function addToCart(id) {
  const product = products.find(p => p.id === id);
  cart.push(product);
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCart();
}

function updateCart() {
  document.getElementById("cart-count").innerText = cart.length;
}

function goToCart() {
  window.location.href = "cart.html";
}

updateCart();
renderProducts();