let cart = JSON.parse(localStorage.getItem("cart")) || [];

function renderCart() {
  let total = 0;
  const container = document.getElementById("cart-items");
  container.innerHTML = "";

  cart.forEach((item, i) => {
    total += item.price;
    container.innerHTML += `
      <div class="product">
        <h3>${item.name}</h3>
        <p>R$ ${item.price}</p>
        <button onclick="removeItem(${i})">Remover</button>
      </div>
    `;
  });

  document.getElementById("total").innerText = "Total: R$ " + total;
}

function removeItem(i) {
  cart.splice(i, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
}

function checkout() {
  alert("Compra finalizada!");
  localStorage.removeItem("cart");
  location.reload();
}

function goHome() {
  window.location.href = "index.html";
}

renderCart();