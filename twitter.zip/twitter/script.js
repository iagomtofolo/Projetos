const firebaseConfig = {
  apiKey: "SUA_API_KEY",
  authDomain: "SEU_DOMINIO",
  projectId: "SEU_PROJETO"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

// AUTH
function login() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  auth.signInWithEmailAndPassword(email, password);
}

function register() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  auth.createUserWithEmailAndPassword(email, password);
}

function logout() {
  auth.signOut();
}

// STATE
auth.onAuthStateChanged(user => {
  document.getElementById('auth').style.display = user ? 'none' : 'flex';
});

// POSTS
function createPost() {
  const text = document.getElementById('postInput').value;

  db.collection('posts').add({
    text,
    likes: 0,
    created: Date.now()
  });
}

// LOAD POSTS
const postsDiv = document.getElementById('posts');

db.collection('posts').orderBy('created', 'desc')
.onSnapshot(snapshot => {
  postsDiv.innerHTML = '';

  snapshot.forEach(doc => {
    const post = doc.data();

    const div = document.createElement('div');
    div.className = 'post';

    div.innerHTML = `
      <p>${post.text}</p>
      <button onclick="likePost('${doc.id}', ${post.likes})">❤️ ${post.likes}</button>
    `;

    postsDiv.appendChild(div);
  });
});

function likePost(id, likes) {
  db.collection('posts').doc(id).update({
    likes: likes + 1
  });
}
